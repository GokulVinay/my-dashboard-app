# Frontend Trainee Assignment: Dynamic Dashboard

## Project Overview

This project involves creating a dynamic dashboard page that allows users to manage widgets within various categories. Users can add, remove, and search for widgets dynamically. The dashboard should be built using JSON to define the categories and widgets.

## Features

1. **Dynamic Dashboard Creation:**
   - Use JSON to define categories and widgets.
   - Each category can contain multiple widgets.

2. **Widget Management:**
   - Add new widgets to categories dynamically.
   - Remove widgets from categories dynamically.

3. **Widget Details:**
   - Display random text for each widget for assignment purposes.

4. **User Interactions:**
   - Users can add widgets by specifying the widget name and text.
   - Widgets can be removed using a cross icon on each widget.
   - Widgets can also be removed by unchecking them in the "Add Category" section.
   - Search functionality to find widgets in the list.

## Development Guidelines

1. **Technologies:**
   - Use **React** to build the dashboard page.

2. **State Management:**
   - Use **Redux** to handle adding and removing widgets locally.

3. **Code Submission:**
   - Share the code via a GitHub link or as a ZIP file.

4. **Running the Application:**
   - Provide detailed steps to run the application locally.

## Getting Started

### Prerequisites

- Node.js (https://nodejs.org/)
- npm or yarn (https://www.npmjs.com/ or https://yarnpkg.com/)


